import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get('http://localhost:9999/data');
      setData(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div>
      <h1>Sample Data</h1>
      <div style={{backgroundColor:'yellow'}}>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        {data.map((item, index) => (
          <div key={index} style={{ marginRight: '5cm', position: 'relative' }}>
            <div style={{ position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)' }}>
              {item.ts}
            </div>
            <div style={{ width: '10px', height: '20px', backgroundColor: item.machine_status === 0 ? 'yellow' : item.machine_status === 1 ? 'green' : 'red' }}></div>
          </div>
        ))}
      </div>
      </div>
    </div>
  );
}

export default App;
